<!Doctype html>
<html lang="pt-br">
    <head>
        <meta charset="utf-8">
        <title>Full Stack Eletro</title>
        <link rel="stylesheet" href="./css/estilo.css">
    </head>

    <body>
        <?php include_once('menu.html')?> 
        <main>
            <header>
                <h1>Seja bem vindo(a)!</h1>
            </header>    

            <p> Aqui em nossa loja, <i>programadores tem desconto</i> nos produtos para sua casa!</p>
            

            <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
            
            <br><br>
        </main>

        <footer class="rodape">
            <p id="cor_destaque">Formas de Pagamento:</p>
            <img width="30%" src="./imagens/formas_de_pagamento.jpg" alt="Formas de pagamento"> 
            <p id="recodepro">&copy; Recode Pro</p>
        </footer>
    </body>
</html>